import type { Player, Round, Tournament } from '../types/tournament';
import { buildTablesForRound } from './roundGenerator';

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function aggregatePointsThroughRound(
  tournament: Tournament,
  upToRoundInclusive: number
): Map<string, number> {
  const map = new Map<string, number>();
  for (const p of tournament.players) {
    map.set(p.id, 0);
  }
  for (const round of tournament.rounds) {
    if (round.number > upToRoundInclusive) {
      break;
    }
    for (const table of round.tables) {
      if (!table.results || table.results.length !== table.players.length) {
        continue;
      }
      for (const r of table.results) {
        map.set(r.playerId, (map.get(r.playerId) ?? 0) + r.points);
      }
    }
  }
  return map;
}

function pickTopFourWithTieRandom(
  sortedByPoints: Player[],
  points: Map<string, number>
): Player[] {
  const selected: Player[] = [];
  let i = 0;
  while (selected.length < 4 && i < sortedByPoints.length) {
    const score = points.get(sortedByPoints[i].id) ?? 0;
    const group: Player[] = [];
    while (
      i < sortedByPoints.length &&
      (points.get(sortedByPoints[i].id) ?? 0) === score
    ) {
      group.push(sortedByPoints[i]);
      i++;
    }
    if (selected.length + group.length <= 4) {
      selected.push(...group);
    } else {
      const need = 4 - selected.length;
      const shuffled = shuffleArray([...group]);
      selected.push(...shuffled.slice(0, need));
      break;
    }
  }
  return selected;
}

export function buildRoundThree(tournament: Tournament): Round {
  const previousRounds = tournament.rounds;
  const points = aggregatePointsThroughRound(tournament, 2);
  const sorted = [...tournament.players].sort((a, b) => {
    const pa = points.get(a.id) ?? 0;
    const pb = points.get(b.id) ?? 0;
    if (pb !== pa) {
      return pb - pa;
    }
    return a.name.localeCompare(b.name, 'pt-BR');
  });

  const finalists = pickTopFourWithTieRandom(sorted, points);
  const finalistIds = new Set(finalists.map((p) => p.id));
  const rest = tournament.players.filter((p) => !finalistIds.has(p.id));

  const tables: Table[] = [];

  if (rest.length === 0) {
    tables.push({
      id: 'round-3-table-1',
      players: finalists,
      isFinalTable: true,
    });
  } else if (rest.length <= 2) {
    tables.push({
      id: 'round-3-table-1',
      players: [...finalists, ...rest],
      isFinalTable: true,
    });
  } else {
    tables.push({
      id: 'round-3-table-1',
      players: finalists,
      isFinalTable: true,
    });
    tables.push(...buildTablesForRound(rest, 3, 2, previousRounds));
  }

  return {
    id: 'round-3',
    number: 3,
    tables,
  };
}

export function isRoundFullyScored(round: Round | undefined): boolean {
  if (!round || round.tables.length === 0) {
    return false;
  }
  return round.tables.every(
    (t) => t.results && t.results.length === t.players.length
  );
}
