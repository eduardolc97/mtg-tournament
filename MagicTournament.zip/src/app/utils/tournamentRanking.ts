import type { Tournament, PlayerStats } from '../types/tournament';

export function calculatePlayerStats(tournament: Tournament): PlayerStats[] {
  const statsMap: Record<string, PlayerStats> = {};

  tournament.players.forEach((player) => {
    statsMap[player.id] = {
      playerId: player.id,
      playerName: player.name,
      pointsByRound: [0, 0, 0],
      totalPoints: 0,
    };
  });

  for (const round of tournament.rounds) {
    const ri = round.number - 1;
    if (ri < 0 || ri > 2) {
      continue;
    }
    for (const table of round.tables) {
      if (!table.results || table.results.length !== table.players.length) {
        continue;
      }
      for (const r of table.results) {
        const stats = statsMap[r.playerId];
        if (stats) {
          stats.pointsByRound[ri] += r.points;
          stats.totalPoints += r.points;
        }
      }
    }
  }

  const statsArray = Object.values(statsMap);
  statsArray.sort((a, b) => {
    if (b.totalPoints !== a.totalPoints) {
      return b.totalPoints - a.totalPoints;
    }
    for (let i = 2; i >= 0; i--) {
      if (b.pointsByRound[i] !== a.pointsByRound[i]) {
        return b.pointsByRound[i] - a.pointsByRound[i];
      }
    }
    return a.playerName.localeCompare(b.playerName, 'pt-BR');
  });

  return statsArray;
}
