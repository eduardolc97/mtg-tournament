import { Tournament } from '../../types/tournament';
import { calculatePlayerStats } from '../../utils/tournamentRanking';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Trophy, Crown } from 'lucide-react';

interface RankingTabProps {
  tournament: Tournament;
}

function hasRound(tournament: Tournament, roundNumber: number): boolean {
  return tournament.rounds.some((r) => r.number === roundNumber);
}

export default function RankingTab({ tournament }: RankingTabProps) {
  const stats = calculatePlayerStats(tournament);
  const r1 = hasRound(tournament, 1);
  const r2 = hasRound(tournament, 2);
  const r3 = hasRound(tournament, 3);

  if (stats.every((s) => s.totalPoints === 0)) {
    return (
      <Card className="bg-slate-900/50 border-purple-900/50 backdrop-blur">
        <CardContent className="py-12 text-center">
          <Trophy className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-400">Nenhum resultado registrado ainda.</p>
          <p className="text-slate-500 text-sm mt-2">
            Complete as rodadas para ver o ranking.
          </p>
        </CardContent>
      </Card>
    );
  }

  const roundCell = (roundOk: boolean, value: number) => {
    if (!roundOk) {
      return (
        <span className="text-slate-500 tabular-nums">—</span>
      );
    }
    return (
      <span className="text-white tabular-nums">{value}</span>
    );
  };

  return (
    <Card className="bg-slate-900/50 border-purple-900/50 backdrop-blur overflow-hidden">
      <CardHeader className="[@media(orientation:landscape)_and_(max-height:500px)]:py-3">
        <CardTitle className="text-white flex items-center gap-2 text-lg [@media(orientation:landscape)_and_(max-height:500px)]:text-base">
          <Trophy className="w-5 h-5 text-yellow-400 shrink-0" />
          Classificação geral
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-700 hover:bg-transparent">
                <TableHead className="text-slate-300 w-14 min-w-[3rem]">
                  Pos.
                </TableHead>
                <TableHead className="text-slate-300 min-w-[120px]">
                  Jogador
                </TableHead>
                <TableHead className="text-slate-300 text-center w-14 px-1">
                  R1
                </TableHead>
                <TableHead className="text-slate-300 text-center w-14 px-1">
                  R2
                </TableHead>
                <TableHead className="text-slate-300 text-center w-14 px-1">
                  R3
                </TableHead>
                <TableHead className="text-slate-300 text-center w-16 px-1">
                  Tot.
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.map((player, index) => {
                const position = index + 1;
                const isLeader = position === 1 && player.totalPoints > 0;

                return (
                  <TableRow
                    key={player.playerId}
                    className={`border-slate-700 ${
                      isLeader
                        ? 'bg-gradient-to-r from-yellow-900/20 to-transparent hover:from-yellow-900/30'
                        : 'hover:bg-slate-800/50'
                    }`}
                  >
                    <TableCell className="py-2 [@media(orientation:landscape)_and_(max-height:500px)]:py-1">
                      <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-white font-semibold text-sm">
                        {position}
                      </div>
                    </TableCell>
                    <TableCell className="py-2 [@media(orientation:landscape)_and_(max-height:500px)]:py-1">
                      <span
                        className={`${isLeader ? 'text-yellow-300 font-semibold' : 'text-white'} text-sm [@media(orientation:landscape)_and_(max-height:500px)]:text-xs`}
                      >
                        {player.playerName}
                        {isLeader && (
                          <Crown className="w-4 h-4 inline ml-1 text-yellow-400" />
                        )}
                      </span>
                    </TableCell>
                    <TableCell className="text-center py-2 [@media(orientation:landscape)_and_(max-height:500px)]:py-1">
                      {roundCell(r1, player.pointsByRound[0])}
                    </TableCell>
                    <TableCell className="text-center py-2 [@media(orientation:landscape)_and_(max-height:500px)]:py-1">
                      {roundCell(r2, player.pointsByRound[1])}
                    </TableCell>
                    <TableCell className="text-center py-2 [@media(orientation:landscape)_and_(max-height:500px)]:py-1">
                      {roundCell(r3, player.pointsByRound[2])}
                    </TableCell>
                    <TableCell className="text-center py-2 [@media(orientation:landscape)_and_(max-height:500px)]:py-1">
                      <span
                        className={`font-bold tabular-nums ${isLeader ? 'text-yellow-400 text-base' : 'text-purple-400'}`}
                      >
                        {player.totalPoints}
                      </span>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
