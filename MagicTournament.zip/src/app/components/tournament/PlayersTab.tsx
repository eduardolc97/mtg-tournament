import { Player } from '../../types/tournament';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { User } from 'lucide-react';

interface PlayersTabProps {
  players: Player[];
}

export default function PlayersTab({ players }: PlayersTabProps) {
  return (
    <Card className="bg-slate-900/50 border-purple-900/50 backdrop-blur">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <User className="w-5 h-5 text-blue-400" />
          Lista de Jogadores ({players.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 [@media(orientation:landscape)_and_(max-height:500px)]:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 gap-3 [@media(orientation:landscape)_and_(max-height:500px)]:gap-2 sm:gap-4">
          {players.map((player, index) => (
            <div
              key={player.id}
              className="bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 flex items-center gap-3 hover:bg-slate-800/70 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white font-semibold">
                {index + 1}
              </div>
              <span className="text-white">{player.name}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
