import type { Round } from '../../types/tournament';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';

interface RoundPresentationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tournamentName: string;
  round: Round;
}

export default function RoundPresentationDialog({
  open,
  onOpenChange,
  tournamentName,
  round,
}: RoundPresentationDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="!fixed !inset-0 !left-0 !top-0 !flex !h-[100dvh] !max-h-[100dvh] !w-screen !max-w-none !translate-x-0 !translate-y-0 flex-col gap-4 rounded-none border-slate-800 bg-slate-950 p-4 pt-14 sm:p-8 sm:pt-16 md:gap-6"
        closeClassName="text-white opacity-95 hover:opacity-100 hover:bg-white/15 data-[state=open]:text-white [&_svg]:size-6"
      >
        <DialogHeader className="shrink-0 space-y-1 text-center sm:text-center">
          <DialogTitle className="text-xl text-white sm:text-2xl md:text-3xl">
            Rodada {round.number}
          </DialogTitle>
          <p className="text-sm text-slate-400 md:text-base">{tournamentName}</p>
          <DialogDescription className="sr-only">
            Mesas e jogadores da rodada {round.number} para leitura em grupo.
          </DialogDescription>
        </DialogHeader>

        <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 overflow-y-auto md:grid-cols-2 md:gap-8">
          {round.tables.map((table, tableIndex) => (
            <div
              key={table.id}
              className="flex flex-col rounded-2xl border border-slate-700/80 bg-slate-900/60 p-4 md:p-8"
            >
              <h3 className="mb-4 text-center text-2xl font-bold text-purple-300 md:mb-6 md:text-4xl">
                Mesa {tableIndex + 1}
              </h3>
              <ul className="flex flex-col gap-3 md:gap-4">
                {table.players.map((player) => (
                  <li
                    key={player.id}
                    className="text-center text-lg font-medium text-white md:text-2xl"
                  >
                    {player.name}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
