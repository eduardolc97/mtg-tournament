import { Link } from 'react-router';
import { useTournaments } from '../context/TournamentContext';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Trophy, Users, Calendar, Plus, Loader2, ListOrdered } from 'lucide-react';
import { monthLabel } from '../utils/monthlyLeague';

export default function Dashboard() {
  const { tournaments, loading } = useTournaments();

  return (
    <div className="min-h-[100dvh] bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
      <div className="container mx-auto px-3 py-6 max-w-6xl sm:px-4 sm:py-8 [@media(orientation:landscape)_and_(max-height:500px)]:py-4 [@media(orientation:landscape)_and_(max-height:500px)]:px-3">
        <div className="text-center mb-8 sm:mb-12 [@media(orientation:landscape)_and_(max-height:500px)]:mb-4">
          <div className="flex items-center justify-center gap-2 sm:gap-3 mb-3 sm:mb-4 [@media(orientation:landscape)_and_(max-height:500px)]:mb-2">
            <Trophy className="w-9 h-9 sm:w-12 sm:h-12 text-yellow-400 shrink-0 [@media(orientation:landscape)_and_(max-height:500px)]:w-8 [@media(orientation:landscape)_and_(max-height:500px)]:h-8" />
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 via-blue-400 to-purple-400 bg-clip-text text-transparent [@media(orientation:landscape)_and_(max-height:500px)]:text-xl">
              Campeonato Commander
            </h1>
          </div>
          <p className="text-slate-300 text-sm sm:text-lg [@media(orientation:landscape)_and_(max-height:500px)]:text-xs">
            Gerencie torneios de Magic: The Gathering - EDH
          </p>
        </div>

        <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 mb-6 sm:mb-8 [@media(orientation:landscape)_and_(max-height:500px)]:mb-4">
          <Link to="/create">
            <Button
              size="lg"
              className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg shadow-purple-500/50 hover:shadow-purple-500/70 transition-all"
            >
              <Plus className="w-5 h-5 mr-2" />
              Novo Campeonato
            </Button>
          </Link>
          <Link to="/liga">
            <Button
              size="lg"
              variant="outline"
              className="w-full sm:w-auto border-purple-500/50 text-purple-200 hover:bg-purple-950/50 hover:text-white"
            >
              <ListOrdered className="w-5 h-5 mr-2" />
              Liga do mês
            </Button>
          </Link>
        </div>

        {/* Tournament List */}
        <div>
          <h2 className="text-xl sm:text-2xl font-semibold text-white mb-4 sm:mb-6 flex items-center gap-2 [@media(orientation:landscape)_and_(max-height:500px)]:text-lg [@media(orientation:landscape)_and_(max-height:500px)]:mb-3">
            <Calendar className="w-5 h-5 sm:w-6 sm:h-6 text-purple-400 shrink-0" />
            Campeonatos
          </h2>
          
          {loading ? (
            <Card className="bg-slate-900/50 border-slate-700 backdrop-blur">
              <CardContent className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400">
                <Loader2 className="w-10 h-10 animate-spin text-purple-400" />
                <p>Carregando campeonatos…</p>
              </CardContent>
            </Card>
          ) : tournaments.length === 0 ? (
            <Card className="bg-slate-900/50 border-slate-700 backdrop-blur">
              <CardContent className="py-12 text-center">
                <Trophy className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">Nenhum campeonato criado ainda.</p>
                <p className="text-slate-500 text-sm mt-2">
                  Crie seu primeiro campeonato para começar!
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 [@media(orientation:landscape)_and_(max-height:500px)]:grid-cols-2 md:grid-cols-2 gap-4 [@media(orientation:landscape)_and_(max-height:500px)]:gap-3 md:gap-6">
              {tournaments.map((tournament) => (
                <Link key={tournament.id} to={`/tournament/${tournament.id}`}>
                  <Card className="bg-slate-900/50 border-purple-900/50 backdrop-blur hover:bg-slate-900/70 hover:border-purple-700/50 transition-all cursor-pointer group hover:shadow-lg hover:shadow-purple-500/20">
                    <CardHeader>
                      <CardTitle className="text-white group-hover:text-purple-300 transition-colors">
                        {tournament.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4 text-slate-300">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-blue-400" />
                          <span className="text-sm">{tournament.players.length} jogadores</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Trophy className="w-4 h-4 text-yellow-400" />
                          <span className="text-sm">
                            {tournament.rounds.length} rodada
                            {tournament.rounds.length !== 1 ? 's' : ''}
                            {tournament.rounds.length === 2
                              ? ' (+ final)'
                              : ''}
                          </span>
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500">
                        <span className="text-purple-300/90 capitalize">
                          Liga: {monthLabel(tournament.leagueYear, tournament.leagueMonth)}
                        </span>
                        <span className="text-slate-600">·</span>
                        <span>
                          Criado em{' '}
                          {new Date(tournament.createdAt).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
